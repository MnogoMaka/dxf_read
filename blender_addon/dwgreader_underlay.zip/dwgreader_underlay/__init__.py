"""Аддон Blender: DWG/DXF → плоская подложка площадки.

Код разбора чертежа лежит в комплекте (пакет dxf_read). Считает его Python,
который идёт вместе с Blender. Папку проекта указывать не нужно.

Установка: zip этой папки → Edit → Preferences → Add-ons → Install from Disk.
После включения один раз нажмите «Установить библиотеки».
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import threading
from pathlib import Path

import bpy
from bpy.props import BoolProperty, CollectionProperty, EnumProperty, FloatProperty, IntProperty, StringProperty
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup, UIList

from .build_scene import build


bl_info = {
    "name": "Подложка DWG",
    "author": "DWGREADER",
    "version": (1, 2, 0),
    "blender": (4, 0, 0),
    "location": "3D Viewport → Sidebar → Подложка",
    "description": "DXF → проверка слоёв → благоустройство в сцене",
    "category": "Import-Export",
}

MARKER = "UNDERLAY_JSON="
EMPTY_MARKER = "UNDERLAY_EMPTY="
LAYERS_MARKER = "LAYERS_JSON="
LAYER_CATEGORIES = (
    ("none", "None", "Тип не задан"),
    ("site_boundary", "Граница", "Граница участка"),
    ("building", "Здания", "Здания и пристройки"),
    ("pavement", "Покрытия", "Проезды, тротуары, площадки"),
    ("green", "Газоны", "Газоны и цветники"),
    ("vegetation", "Посадки", "Деревья и кустарники"),
    ("furniture", "МАФ", "Скамьи, урны, оборудование"),
    ("fence", "Ограждения", "Заборы и ограды"),
)
CATEGORY_IDS = {item[0] for item in LAYER_CATEGORIES}
PIP_PACKAGES = ("ezdxf", "shapely", "numpy", "mapbox-earcut")
WINGET_ODA_ID = "ODA.ODAFileConverter"
JUNK_TOKENS = (
    "НОМ._ПЕРА, LABEL_, POINTS_GRID, POINTS_GRADE, NULL_WORKS, "
    "ИНТЕРЬЕР, ГОРИЗОНТАЛ, ВЕРТИКАЛК, DEFPOINTS, ЭКСПЛИКАЦ, "
    "ВЫНОСК, ШТАМП, C-ROAD-, ТПП_РАЗМЕР, ТПП_ТЕКСТ, "
    "РАЗМЕР, РАЗМЕТК, ОСИ, ОСЕВ, OSEV, "
    "ТЕКСТ, PDF , PDF_, "
    "ВИДОВОЙ ЭКРАН, ОДД, ДВИЖЕНИ, "
    "ХАРАКТЕРИСТИКА, ТРАССА, ВЕНТИЛЯТОР, КОЛОД, СЕТИ, "
    "ГРАНИЦА УЛИЦ, ГРАНИЦА ЗАКАЗ, ГРАНИЦА РАСТИТЕЛЬНОСТ, "
    "СИТУАЦИОН, КАРТОГРАМ, КАТОГРАМ, ЛЕГЕНД, "
    "REV_А-, REV_A-, VOLUME, TABLE, GRID"
)


def _addon_dir() -> Path:
    return Path(__file__).resolve().parent


def _vendor_dir() -> Path:
    return _addon_dir() / "vendor"


def _engine_dir() -> Path:
    """Каталог, внутри которого лежит пакет dxf_read."""
    addon_dir = _addon_dir()
    if (addon_dir / "dxf_read" / "__init__.py").is_file():
        return addon_dir
    repo = addon_dir.parents[2]
    if (repo / "dxf_read" / "__init__.py").is_file():
        return repo
    raise FileNotFoundError("В аддоне нет пакета dxf_read")


def _python_folders() -> list[Path]:
    folders = [Path(sys.prefix) / "bin", Path(sys.prefix)]
    binary = Path(getattr(bpy.app, "binary_path", "") or "")
    if not binary:
        return folders
    # macOS: Blender.app/Contents/MacOS/Blender → Contents/Resources/4.x/python/bin
    resources = binary.parent.parent / "Resources"
    if resources.is_dir():
        folders.extend(resources.glob("*/python/bin"))
    folders.extend(binary.parent.glob("*/python/bin"))
    return folders


def _is_python_binary(path: Path) -> bool:
    name = path.name.lower()
    if not path.is_file() or "config" in name:
        return False
    return name.startswith("python") and not name.endswith((".dll", ".dylib", ".so"))


def _blender_python() -> Path:
    found: list[Path] = []
    seen: set[Path] = set()
    for folder in _python_folders():
        if not folder.is_dir():
            continue
        for candidate in folder.iterdir():
            resolved = candidate.resolve()
            if resolved in seen or not _is_python_binary(candidate):
                continue
            seen.add(resolved)
            found.append(candidate)
    found.sort(key=lambda path: (not path.name.lower().startswith("python3."), path.name.lower()))
    if found:
        return found[0]
    raise FileNotFoundError(
        "Не найден Python рядом с Blender. Библиотеки ставятся его pip."
    )


def _oda_roots() -> tuple[Path, ...]:
    if sys.platform == "darwin":
        return (Path("/Applications"), Path.home() / "Applications")
    if sys.platform.startswith("linux"):
        return (Path("/usr/bin"), Path("/usr/local/bin"), Path.home())
    return (
        Path(r"C:\Program Files\ODA"),
        Path(r"C:\Program Files (x86)\ODA"),
        Path(r"C:\Program Files"),
    )


def _oda_installed(prefs=None) -> bool:
    """Есть ли ODA File Converter: путь из настроек или стандартные папки системы."""
    if prefs is not None and prefs.oda_converter.strip():
        return Path(bpy.path.abspath(prefs.oda_converter.strip())).is_file()
    for root in _oda_roots():
        if not root.is_dir():
            continue
        patterns = (
            "ODAFileConverter*/ODAFileConverter.exe",
            "ODAFileConverter.exe",
            "ODAFileConverter*.app/Contents/MacOS/ODAFileConverter",
            "ODAFileConverter",
        )
        if any(path.is_file() for pattern in patterns for path in root.glob(pattern)):
            return True
    return False


def _deps_ready() -> bool:
    vendor = _vendor_dir()
    return all((vendor / name).exists() for name in ("ezdxf", "shapely", "mapbox_earcut", "numpy"))


def _addon_prefs(context):
    package = __package__ or __name__
    addon = context.preferences.addons.get(package)
    return addon.preferences if addon is not None else None


def _tokens(text: str) -> list[str]:
    items: list[str] = []
    for part in text.replace(";", ",").replace("\n", ",").split(","):
        token = part.strip().upper().replace("Ё", "Е")
        if token:
            items.append(token)
    return items


def _documents_converter() -> Path:
    """Папка «Документы/converter», с учётом переноса Documents в OneDrive."""
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes

        class GUID(ctypes.Structure):
            _fields_ = [
                ("Data1", wintypes.DWORD),
                ("Data2", wintypes.WORD),
                ("Data3", wintypes.WORD),
                ("Data4", wintypes.BYTE * 8),
            ]

        folder_id = GUID(
            0xFDD39AD0, 0x238F, 0x46AF,
            (wintypes.BYTE * 8)(0xAD, 0xB4, 0x6C, 0x85, 0x48, 0x03, 0x69, 0xC7),
        )
        shell32 = ctypes.windll.shell32
        ole32 = ctypes.windll.ole32
        shell32.SHGetKnownFolderPath.argtypes = [
            ctypes.POINTER(GUID), wintypes.DWORD, wintypes.HANDLE,
            ctypes.POINTER(ctypes.c_wchar_p),
        ]
        shell32.SHGetKnownFolderPath.restype = ctypes.HRESULT
        pointer = ctypes.c_wchar_p()
        if shell32.SHGetKnownFolderPath(ctypes.byref(folder_id), 0, None, ctypes.byref(pointer)) == 0:
            documents = Path(pointer.value)
            ole32.CoTaskMemFree(pointer)
            return documents / "converter"
    return Path.home() / "Documents" / "converter"


DEFAULT_OUTPUT = str(_documents_converter())


def _output_dir(prefs, source: Path) -> Path:
    raw = prefs.output_dir.strip()
    if raw:
        path = Path(bpy.path.abspath(raw))
        if not path.is_absolute():
            path = source.parent / path
    else:
        path = Path(DEFAULT_OUTPUT)
    path.mkdir(parents=True, exist_ok=True)
    return path


def _settings_payload(prefs, source: Path) -> dict:
    oda = ""
    if prefs.oda_converter.strip():
        oda = bpy.path.abspath(prefs.oda_converter.strip())
    return {
        "site_cluster_radius_m": float(prefs.site_cluster_radius_m),
        "generic_fill_associate_m": float(prefs.generic_fill_associate_m),
        "min_arrangement_area_m2": float(prefs.min_arrangement_area_m2),
        "flattening_distance_m": float(prefs.flattening_distance_m),
        "batch_size": int(prefs.batch_size),
        "llm_timeout": float(prefs.llm_timeout),
        "fill_polyline_tokens": _tokens(prefs.fill_polyline_tokens),
        "junk_layer_tokens": _tokens(prefs.junk_layer_tokens),
        "llm_model": prefs.llm_model.strip(),
        "llm_base_url": prefs.llm_base_url.strip(),
        "llm_api_key": prefs.llm_api_key,
        "oda_converter": oda,
        "output_dir": str(_output_dir(prefs, source)),
    }


def _python_env() -> dict[str, str]:
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONPATH"] = os.pathsep.join(
        part for part in (str(_vendor_dir()), str(_engine_dir()), env.get("PYTHONPATH", "")) if part
    )
    return env


def _redraw(context) -> None:
    screen = context.screen
    if screen is None:
        return
    for area in screen.areas:
        if area.type == "VIEW_3D":
            area.tag_redraw()


class DWGREADER_AddonPreferences(AddonPreferences):
    bl_idname = __package__ or __name__

    oda_converter: StringProperty(
        name="ODA File Converter",
        description="Файл ODA File Converter. Пусто — искать в Program Files или /Applications. Нужен только для DWG",
        subtype="FILE_PATH",
        default="",
    )
    output_dir: StringProperty(
        name="Папка результатов",
        description="Куда писать DXF и JSON. По умолчанию — Документы/converter",
        subtype="DIR_PATH",
        default=DEFAULT_OUTPUT,
    )
    llm_model: StringProperty(
        name="Модель",
        description="Имя модели на OpenAI-совместимом сервере",
        default="qwen/qwen3-vl-30b-a3b-instruct",
    )
    llm_base_url: StringProperty(
        name="Адрес модели",
        default="https://llm-router.cxm.dev/v1/",
    )
    llm_api_key: StringProperty(
        name="Ключ API",
        subtype="PASSWORD",
        default="",
    )
    llm_timeout: FloatProperty(
        name="Таймаут запроса, с",
        description="Сколько ждать ответ модели на один пакет слоёв",
        default=300.0,
        min=10.0,
        max=3600.0,
    )
    batch_size: IntProperty(
        name="Слоёв в пакете",
        description="Сколько имён слоёв отправлять модели за один запрос",
        default=600,
        min=1,
        max=2000,
    )
    site_cluster_radius_m: FloatProperty(
        name="Радиус кластера, м",
        description="В одном пятне остаются заливки не дальше этого радиуса друг от друга",
        default=400000.0,
        min=1.0,
        soft_max=400000.0,
    )
    generic_fill_associate_m: FloatProperty(
        name="Привязка заливки слоя 0, м",
        description="SOLID на слое 0 относится к зданию, если центр внутри контура и не дальше этого допуска",
        default=15.0,
        min=0.0,
        soft_max=100.0,
    )
    min_arrangement_area_m2: FloatProperty(
        name="Минимальная площадь, м²",
        description="Мельче этого заливки не попадают в подложку",
        default=0.05,
        min=0.0,
        soft_max=10.0,
        precision=3,
    )
    flattening_distance_m: FloatProperty(
        name="Спрямление дуг, м",
        description="Допуск ломаной при разборе дуг и сплайнов",
        default=0.02,
        min=0.001,
        soft_max=1.0,
        precision=3,
    )
    fill_polyline_tokens: StringProperty(
        name="Полилинии-заливки",
        description="Замкнутая полилиния становится пятном, если в имени слоя есть один из фрагментов. Через запятую",
        default="ЗАЛИВ, ЗАПОЛН, ПЯТН",
    )
    junk_layer_tokens: StringProperty(
        name="Служебные слои",
        description="Слой отбрасывается, если в хвосте имени есть один из фрагментов. Через запятую",
        default=JUNK_TOKENS,
    )

    def draw(self, context):
        layout = self.layout
        layout.operator("dwgreader.install_deps", icon="IMPORT")
        layout.prop(self, "oda_converter")
        if not _oda_installed(self):
            layout.operator("dwgreader.install_oda", icon="IMPORT")
        layout.prop(self, "output_dir")

        services = layout.box()
        services.label(text="Классификация слоёв")
        services.prop(self, "llm_model")
        services.prop(self, "llm_base_url")
        services.prop(self, "llm_api_key")
        services.prop(self, "llm_timeout")
        services.prop(self, "batch_size")

        geometry = layout.box()
        geometry.label(text="Геометрия")
        _draw_geometry(geometry, self)

        tokens = layout.box()
        tokens.label(text="Имена слоёв")
        tokens.prop(self, "fill_polyline_tokens")
        tokens.prop(self, "junk_layer_tokens")


def _draw_geometry(layout, prefs) -> None:
    layout.prop(prefs, "site_cluster_radius_m")
    layout.prop(prefs, "generic_fill_associate_m")
    layout.prop(prefs, "min_arrangement_area_m2")
    layout.prop(prefs, "flattening_distance_m")


class DWGREADER_OT_install_deps(Operator):
    bl_idname = "dwgreader.install_deps"
    bl_label = "Установить библиотеки"
    bl_description = "Ставит ezdxf, shapely и earcut в папку аддона через Python Blender"

    _timer = None
    _proc = None
    _thread = None
    _state: dict | None = None

    @classmethod
    def poll(cls, context):
        return not context.window_manager.dwgreader_busy

    def invoke(self, context, event):
        try:
            python = _blender_python()
        except FileNotFoundError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        vendor = _vendor_dir()
        vendor.mkdir(parents=True, exist_ok=True)
        command = [
            str(python), "-m", "pip", "install", "--upgrade",
            "--target", str(vendor), *PIP_PACKAGES,
        ]
        return _start_process(self, context, command, cwd=vendor.parent, env=os.environ.copy(), title="Установка библиотек…")

    def modal(self, context, event):
        return _poll_process(
            self, context, event,
            on_ok="Библиотеки установлены",
            on_err="Не удалось установить библиотеки",
        )

    def _stop(self, context, kill: bool) -> None:
        _stop_process(self, context, kill)


class DWGREADER_OT_install_oda(Operator):
    bl_idname = "dwgreader.install_oda"
    bl_label = "Установить ODA File Converter"
    bl_description = "Ставит ODA File Converter, если его ещё нет: winget в Windows, страница загрузки на Mac"

    _timer = None
    _proc = None
    _thread = None
    _state: dict | None = None

    @classmethod
    def poll(cls, context):
        return not context.window_manager.dwgreader_busy

    def invoke(self, context, event):
        if _oda_installed(_addon_prefs(context)):
            self.report({"INFO"}, "ODA File Converter уже установлен")
            return {"CANCELLED"}
        if sys.platform == "darwin":
            import webbrowser
            webbrowser.open("https://www.opendesign.com/guestfiles/oda_file_converter")
            self.report(
                {"INFO"},
                "Открыта загрузка ODA. Поставьте приложение в /Applications и запустите импорт снова",
            )
            return {"FINISHED"}
        if os.name != "nt":
            self.report({"ERROR"}, "Скачайте ODA File Converter с сайта Open Design Alliance и укажите путь в настройках")
            return {"CANCELLED"}
        winget = shutil.which("winget")
        if not winget:
            self.report({"ERROR"}, "winget не найден. Нужны Windows 10 или 11 с App Installer")
            return {"CANCELLED"}
        command = [
            winget, "install", "--id", WINGET_ODA_ID, "-e",
            "--silent",
            "--accept-package-agreements",
            "--accept-source-agreements",
        ]
        log_dir = Path(DEFAULT_OUTPUT)
        log_dir.mkdir(parents=True, exist_ok=True)
        return _start_process(
            self, context, command, cwd=log_dir, env=os.environ.copy(),
            title="Установка ODA File Converter…",
            log_path=log_dir / "dwgreader_oda_install.log",
        )

    def modal(self, context, event):
        return _poll_process(
            self, context, event,
            on_ok="ODA File Converter установлен",
            on_err="Не удалось установить ODA File Converter",
        )

    def _stop(self, context, kill: bool) -> None:
        _stop_process(self, context, kill)


class DWGREADER_OT_pick_file(Operator):
    bl_idname = "dwgreader.pick_file"
    bl_label = "Выбрать чертёж"
    bl_description = "DWG или DXF"

    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.dwg;*.dxf;*.DWG;*.DXF", options={"HIDDEN"})

    def execute(self, context):
        scene = context.scene
        if scene.dwgreader_source != self.filepath:
            scene.dwgreader_selected.clear()
            scene.dwgreader_ignored.clear()
            scene.dwgreader_classified = ""
        scene.dwgreader_source = self.filepath
        return {"FINISHED"}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class DWGREADER_LayerItem(PropertyGroup):
    layer_name: StringProperty(name="Слой")
    category: EnumProperty(name="Тип", items=LAYER_CATEGORIES, default="none")


class DWGREADER_UL_layers(UIList):
    bl_idname = "DWGREADER_UL_layers"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.label(text=item.layer_name)
        row.prop(item, "category", text="")


def _drawing_path(context) -> Path | None:
    raw = context.scene.dwgreader_source.strip()
    if not raw:
        return None
    path = Path(bpy.path.abspath(raw))
    if path.suffix.lower() not in {".dwg", ".dxf"} or not path.is_file():
        return None
    return path


def _launch_pipeline(operator, context, extra: list[str], title: str, mode: str):
    prefs = _addon_prefs(context)
    if prefs is None:
        operator.report({"ERROR"}, "Настройки аддона недоступны")
        return {"CANCELLED"}
    if not _deps_ready():
        operator.report({"ERROR"}, "Сначала нажмите «Установить библиотеки»")
        return {"CANCELLED"}
    source = _drawing_path(context)
    if source is None:
        operator.report({"ERROR"}, "Выберите существующий файл .dxf или .dwg")
        return {"CANCELLED"}
    if source.suffix.lower() == ".dwg" and not _oda_installed(prefs):
        operator.report({"ERROR"}, "Для DWG нужен ODA File Converter. Нажмите «Установить ODA File Converter»")
        return {"CANCELLED"}
    try:
        python = _blender_python()
        engine = _engine_dir()
    except FileNotFoundError as exc:
        operator.report({"ERROR"}, str(exc))
        return {"CANCELLED"}
    out = _output_dir(prefs, source)
    settings_path = out / "_pipeline_settings.json"
    settings_path.write_text(
        json.dumps(_settings_payload(prefs, source), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    command = [
        str(python), "-m", "dxf_read", str(source),
        "--no-blender", "--settings", str(settings_path),
        *extra,
    ]
    operator._mode = mode
    return _start_process(
        operator, context, command, cwd=engine, env=_python_env(),
        title=title,
        log_path=out / "dwgreader_import.log",
    )


def _fill_review(context, layers_path: Path) -> tuple[int, int]:
    data = json.loads(layers_path.read_text(encoding="utf-8"))
    scene = context.scene
    scene.dwgreader_selected.clear()
    scene.dwgreader_ignored.clear()
    seen: set[str] = set()
    order = [item[0] for item in LAYER_CATEGORIES]
    grouped = data.get("by_category") or {}
    for category in order:
        for name in grouped.get(category) or []:
            text = str(name).strip()
            if not text or text in seen:
                continue
            seen.add(text)
            item = scene.dwgreader_selected.add()
            item.layer_name = text
            item.category = category
    for category, names in grouped.items():
        if category in CATEGORY_IDS:
            continue
        for name in names or []:
            text = str(name).strip()
            if not text or text in seen:
                continue
            seen.add(text)
            item = scene.dwgreader_selected.add()
            item.layer_name = text
            item.category = "none"
    for name in data.get("rejected") or []:
        text = str(name).strip()
        if not text or text in seen:
            continue
        seen.add(text)
        item = scene.dwgreader_ignored.add()
        item.layer_name = text
        item.category = "none"
    scene.dwgreader_selected_index = 0
    scene.dwgreader_ignored_index = 0
    scene.dwgreader_classified = scene.dwgreader_source
    return len(scene.dwgreader_selected), len(scene.dwgreader_ignored)


def _move_layer(source, target, index: int) -> None:
    if index < 0 or index >= len(source):
        return
    item = source[index]
    copy = target.add()
    copy.layer_name = item.layer_name
    copy.category = item.category
    source.remove(index)


class DWGREADER_OT_classify(Operator):
    bl_idname = "dwgreader.classify_layers"
    bl_label = "Разобрать слои"
    bl_description = "Прочитать чертёж и показать слои, которые модель отнесла к благоустройству"
    bl_options = {"REGISTER"}

    _timer = None
    _proc = None
    _thread = None
    _state: dict | None = None
    _mode = "classify"

    @classmethod
    def poll(cls, context):
        return not context.window_manager.dwgreader_busy

    def invoke(self, context, event):
        return _launch_pipeline(
            self, context, ["--classify-only"],
            "Разбор чертежа и классификация слоёв…",
            "classify",
        )

    def modal(self, context, event):
        return _poll_process(
            self, context, event,
            on_ok="",
            on_err="Разбор слоёв не удался",
            mode="classify",
        )

    def _stop(self, context, kill: bool) -> None:
        _stop_process(self, context, kill)


class DWGREADER_OT_exclude(Operator):
    bl_idname = "dwgreader.exclude_layer"
    bl_label = "Убрать слой"
    bl_description = "Убрать выбранный слой из благоустройства"

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return not context.window_manager.dwgreader_busy and len(scene.dwgreader_selected) > 0

    def execute(self, context):
        scene = context.scene
        index = scene.dwgreader_selected_index
        _move_layer(scene.dwgreader_selected, scene.dwgreader_ignored, index)
        scene.dwgreader_selected_index = min(index, len(scene.dwgreader_selected) - 1)
        return {"FINISHED"}


class DWGREADER_OT_include(Operator):
    bl_idname = "dwgreader.include_layer"
    bl_label = "Добавить слой"
    bl_description = "Вернуть пропущенный слой в благоустройство"

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return not context.window_manager.dwgreader_busy and len(scene.dwgreader_ignored) > 0

    def execute(self, context):
        scene = context.scene
        index = scene.dwgreader_ignored_index
        _move_layer(scene.dwgreader_ignored, scene.dwgreader_selected, index)
        scene.dwgreader_ignored_index = min(index, len(scene.dwgreader_ignored) - 1)
        return {"FINISHED"}


class DWGREADER_OT_generate(Operator):
    bl_idname = "dwgreader.generate_underlay"
    bl_label = "Сгенерировать благоустройство"
    bl_description = "Собрать подложку в сцене из подтверждённых слоёв"
    bl_options = set()

    _timer = None
    _proc = None
    _thread = None
    _state: dict | None = None
    _mode = "build"

    @classmethod
    def poll(cls, context):
        scene = context.scene
        return (
            not context.window_manager.dwgreader_busy
            and len(scene.dwgreader_selected) > 0
            and scene.dwgreader_classified == scene.dwgreader_source
        )

    def invoke(self, context, event):
        scene = context.scene
        source = _drawing_path(context)
        prefs = _addon_prefs(context)
        if source is None or prefs is None:
            self.report({"ERROR"}, "Выберите чертёж и разберите слои")
            return {"CANCELLED"}
        groups: dict[str, list[str]] = {}
        for item in scene.dwgreader_selected:
            name = item.layer_name.strip()
            if name:
                groups.setdefault(item.category, []).append(name)
        if not groups:
            self.report({"ERROR"}, "В благоустройстве не осталось слоёв")
            return {"CANCELLED"}
        out = _output_dir(prefs, source)
        groups_path = out / "_confirmed_layers.json"
        groups_path.write_text(
            json.dumps({"by_category": groups}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return _launch_pipeline(
            self, context, ["--groups", str(groups_path)],
            "Сборка благоустройства…",
            "build",
        )

    def modal(self, context, event):
        return _poll_process(
            self, context, event,
            on_ok="",
            on_err="Генерация не удалась",
            mode="build",
        )

    def _stop(self, context, kill: bool) -> None:
        _stop_process(self, context, kill)


class DWGREADER_PT_panel(Panel):
    bl_label = "Благоустройство"
    bl_idname = "DWGREADER_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Подложка"

    def draw(self, context):
        layout = self.layout
        prefs = _addon_prefs(context)
        scene = context.scene
        if not _deps_ready():
            layout.label(text="Библиотеки разбора ещё не стоят")
            layout.operator("dwgreader.install_deps", icon="IMPORT")
            layout.separator()
        if not _oda_installed(prefs):
            layout.label(text="Для DWG не найден ODA File Converter")
            layout.operator("dwgreader.install_oda", icon="IMPORT")
            layout.separator()

        step1 = layout.box()
        step1.label(text="1. Чертёж")
        step1.prop(scene, "dwgreader_source", text="")
        step1.operator("dwgreader.pick_file", icon="FILEBROWSER", text="Загрузить DXF")
        step1.operator("dwgreader.classify_layers", icon="VIEWZOOM")

        reviewed = len(scene.dwgreader_selected) + len(scene.dwgreader_ignored) > 0
        same_file = scene.dwgreader_classified == scene.dwgreader_source and scene.dwgreader_classified != ""
        if reviewed and same_file:
            step2 = layout.box()
            step2.label(text="2. Слои благоустройства")
            step2.label(text="Уберите лишние или верните пропущенные")
            step2.template_list(
                "DWGREADER_UL_layers", "selected",
                scene, "dwgreader_selected",
                scene, "dwgreader_selected_index",
                rows=6,
            )
            step2.operator("dwgreader.exclude_layer", icon="X")
            step2.separator()
            step2.label(text="Пропущенные слои")
            step2.template_list(
                "DWGREADER_UL_layers", "ignored",
                scene, "dwgreader_ignored",
                scene, "dwgreader_ignored_index",
                rows=4,
            )
            step2.operator("dwgreader.include_layer", icon="ADD")
            step2.separator()
            step2.label(text="3. Генерация")
            generate = step2.row()
            generate.scale_y = 1.3
            generate.operator(
                "dwgreader.generate_underlay",
                text="Сгенерировать благоустройство",
                icon="PLAY",
            )
        elif reviewed:
            layout.label(text="Слои от другого файла. Разберите чертёж заново")

        if scene.dwgreader_status:
            layout.label(text=scene.dwgreader_status)
        if prefs is None:
            return
        layout.separator()
        box = layout.box()
        box.label(text="Геометрия")
        _draw_geometry(box, prefs)
        box.prop(prefs, "batch_size")
        layout.label(text="Модель, ODA и токены слоёв — в настройках аддона")


def _start_process(operator, context, command, cwd: Path, env: dict, title: str, log_path: Path | None = None):
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        proc = subprocess.Popen(
            command,
            cwd=str(cwd),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags,
        )
    except OSError as exc:
        operator.report({"ERROR"}, str(exc))
        return {"CANCELLED"}

    state = {
        "status": title,
        "tail": [],
        "json": "",
        "layers": "",
        "empty": "",
        "log": log_path or (cwd / "dwgreader_import.log"),
        "status_locked": False,
    }
    operator._state = state
    operator._proc = proc
    context.window_manager.dwgreader_busy = True
    context.scene.dwgreader_status = title

    def reader() -> None:
        log_file = Path(state["log"]).open("w", encoding="utf-8")
        try:
            stream = proc.stdout
            if stream is None:
                return
            for raw in stream:
                line = raw.rstrip()
                log_file.write(line + "\n")
                log_file.flush()
                tail = state["tail"]
                tail.append(line)
                del tail[:-40]
                if line.startswith(MARKER):
                    state["json"] = line[len(MARKER):].strip()
                elif line.startswith(LAYERS_MARKER):
                    state["layers"] = line[len(LAYERS_MARKER):].strip()
                elif line.startswith(EMPTY_MARKER):
                    state["empty"] = line[len(EMPTY_MARKER):].strip()
                elif line.startswith("STATUS="):
                    state["status"] = line[len("STATUS="):].strip()[:180]
                    state["status_locked"] = True
                elif line and not state["status_locked"]:
                    state["status"] = line[:180]
        finally:
            log_file.close()

    operator._thread = threading.Thread(target=reader, daemon=True)
    operator._thread.start()
    operator._timer = context.window_manager.event_timer_add(0.4, window=context.window)
    context.window_manager.modal_handler_add(operator)
    return {"RUNNING_MODAL"}


def _stop_process(operator, context, kill: bool) -> None:
    if operator._timer is not None:
        context.window_manager.event_timer_remove(operator._timer)
        operator._timer = None
    proc = operator._proc
    if kill and proc is not None and proc.poll() is None:
        proc.kill()
    operator._proc = None
    context.window_manager.dwgreader_busy = False


def _poll_process(operator, context, event, on_ok: str, on_err: str, build: bool = False, mode: str = ""):
    if event.type == "ESC":
        operator._stop(context, kill=True)
        context.scene.dwgreader_status = "Отменено"
        return {"CANCELLED"}
    if event.type != "TIMER":
        return {"PASS_THROUGH"}

    proc = operator._proc
    if proc is None or proc.poll() is None:
        context.scene.dwgreader_status = str((operator._state or {}).get("status") or "")
        _redraw(context)
        return {"RUNNING_MODAL"}

    thread = operator._thread
    if thread is not None:
        thread.join(timeout=2)
    state = operator._state or {}
    operator._stop(context, kill=False)

    if mode == "classify":
        layers_raw = str(state.get("layers") or "")
        layers_path = Path(layers_raw) if layers_raw else None
        if proc.returncode != 0 or layers_path is None or not layers_path.is_file():
            tail = state.get("tail") or []
            detail = tail[-1] if tail else f"код {proc.returncode}"
            context.scene.dwgreader_status = f"Ошибка: {detail}"
            operator.report({"ERROR"}, f"{on_err}. Журнал: {state.get('log')}")
            return {"CANCELLED"}
        selected, ignored = _fill_review(context, layers_path)
        context.scene.dwgreader_status = f"Слои разобраны: {selected} в благоустройстве, {ignored} пропущено"
        operator.report({"INFO"}, context.scene.dwgreader_status)
        _redraw(context)
        return {"FINISHED"}

    if (build or mode == "build") and state.get("empty"):
        message = str(state["empty"])
        context.scene.dwgreader_status = message[:180]
        operator.report({"WARNING"}, message)
        return {"FINISHED"}

    if build or mode == "build":
        if proc.returncode != 0 or not state.get("json"):
            tail = state.get("tail") or []
            detail = tail[-1] if tail else f"код {proc.returncode}"
            context.scene.dwgreader_status = f"Ошибка: {detail}"
            operator.report({"ERROR"}, f"{on_err}. Журнал: {state.get('log')}")
            return {"CANCELLED"}
        json_path = Path(str(state["json"]))
        if not json_path.is_file():
            context.scene.dwgreader_status = "JSON подложки не найден"
            operator.report({"ERROR"}, str(json_path))
            return {"CANCELLED"}
        try:
            count = build_underlay(json_path)
        except Exception as exc:
            context.scene.dwgreader_status = f"Ошибка сборки: {exc}"
            operator.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        context.scene.dwgreader_status = f"Готово: благоустройство в сцене, слоёв {count}"
        operator.report({"INFO"}, f"Благоустройство собрано, слоёв: {count}")
        return {"FINISHED"}

    if proc.returncode != 0:
        tail = state.get("tail") or []
        detail = tail[-1] if tail else f"код {proc.returncode}"
        context.scene.dwgreader_status = f"Ошибка: {detail}"
        operator.report({"ERROR"}, f"{on_err}. Журнал: {state.get('log')}")
        return {"CANCELLED"}
    context.scene.dwgreader_status = on_ok
    operator.report({"INFO"}, on_ok)
    return {"FINISHED"}


def build_underlay(json_path: Path) -> int:
    return build(json_path)


CLASSES = (
    DWGREADER_AddonPreferences,
    DWGREADER_LayerItem,
    DWGREADER_UL_layers,
    DWGREADER_OT_install_deps,
    DWGREADER_OT_install_oda,
    DWGREADER_OT_pick_file,
    DWGREADER_OT_classify,
    DWGREADER_OT_exclude,
    DWGREADER_OT_include,
    DWGREADER_OT_generate,
    DWGREADER_PT_panel,
)


def register() -> None:
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.dwgreader_source = StringProperty(
        name="Чертёж",
        description="Файл DWG или DXF",
        subtype="FILE_PATH",
        default="",
    )
    bpy.types.Scene.dwgreader_status = StringProperty(name="Статус", default="")
    bpy.types.Scene.dwgreader_classified = StringProperty(name="Разобранный чертёж", default="")
    bpy.types.Scene.dwgreader_selected = CollectionProperty(type=DWGREADER_LayerItem)
    bpy.types.Scene.dwgreader_ignored = CollectionProperty(type=DWGREADER_LayerItem)
    bpy.types.Scene.dwgreader_selected_index = IntProperty(default=0)
    bpy.types.Scene.dwgreader_ignored_index = IntProperty(default=0)
    bpy.types.WindowManager.dwgreader_busy = BoolProperty(name="Идёт импорт", default=False)
    try:
        addon = bpy.context.preferences.addons.get(__package__ or __name__)
    except Exception:
        addon = None
    if addon is not None:
        prefs = addon.preferences
        if prefs.llm_model in {"", "google/gemma-4-e4b"}:
            prefs.llm_model = "qwen/qwen3-vl-30b-a3b-instruct"
        if prefs.llm_base_url in {"", "http://127.0.0.1:1234/v1"}:
            prefs.llm_base_url = "https://llm-router.cxm.dev/v1/"


def unregister() -> None:
    del bpy.types.WindowManager.dwgreader_busy
    del bpy.types.Scene.dwgreader_ignored_index
    del bpy.types.Scene.dwgreader_selected_index
    del bpy.types.Scene.dwgreader_ignored
    del bpy.types.Scene.dwgreader_selected
    del bpy.types.Scene.dwgreader_classified
    del bpy.types.Scene.dwgreader_status
    del bpy.types.Scene.dwgreader_source
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
